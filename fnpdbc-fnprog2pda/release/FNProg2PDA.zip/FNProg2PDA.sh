#!/bin/bash
java -jar FNProg2PDA.jar
