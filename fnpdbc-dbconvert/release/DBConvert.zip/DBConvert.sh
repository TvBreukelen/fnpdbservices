#!/bin/bash
java -jar DBConvert.jar