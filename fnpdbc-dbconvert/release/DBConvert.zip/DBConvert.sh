﻿#! /bin/bash
clear
java -jar DBConvert.jar
